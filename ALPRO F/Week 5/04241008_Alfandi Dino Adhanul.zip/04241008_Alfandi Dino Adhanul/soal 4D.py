n = int(input("Masukkan nilai: "))

for i in range(1, n+1):
    print ('x' * i)

for i in range(n-1, 0, -1):
    print('x' * i)